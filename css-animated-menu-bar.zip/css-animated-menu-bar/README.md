# CSS Animated Menu Bar

A Pen created on CodePen.io. Original URL: [https://codepen.io/robf1011/pen/ZjBpOZ](https://codepen.io/robf1011/pen/ZjBpOZ).

